package work6;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;

public class two {
	
		public static void main(String[] args) {
			String FileName ="C:/Users/Administrator/Desktop/student.txt";
			try{
				File wFile = new File(FileName);
				FileWriter fw = new FileWriter(wFile);
				PrintWriter pwt = new PrintWriter(fw);
				String Info = "";
				while(!Info.equals("end"))
//				pwt.println(Info);
				pwt.close();
				fw.close();
				
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}


