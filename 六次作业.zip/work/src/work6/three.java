package work6;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class three {
	
		public static void main(String[] args) {
			String FileName ="C:/Users/Administrator/Desktop/student.txt";
			try{
				File aFile = new File(FileName);
				FileReader fr = new FileReader(aFile);
				BufferedReader br = new BufferedReader(fr);
				String express= "";
				while((express=br.readLine())!=null){
					String regex= "((add)|(sub)|(double)|(min)|(max))\\(\\d{1,}(,\\d{1,})?\\)";
					Pattern p = Pattern.compile(regex);
					Matcher m = p.matcher(express);
					String result = express;
					while(m.find()){
						String basicExpress = m.group();
						String s =Cal(basicExpress);
						basicExpress = basicExpress.replaceAll("\\(", "\\\\(");
						basicExpress = basicExpress.replaceAll("\\)", "\\\\)");
//						System.out.println("����ʽΪ��"+result);
						result= result.replaceAll(basicExpress, s);
//						System.out.println("�滻��"+result);
						m = p.matcher(result);
					}
					System.out.println("������Ϊ��");
					System.out.println(express+"="+result);
				}
				br.close();
				fr.close();
				
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		public static String Cal(String s){
			int result=0;
			String title = s.substring(0,s.indexOf("("));
			String num;
			int n1;
			String num2;
			int n2;
			switch(title){
					case "add":num = s.substring(s.indexOf("(")+1,s.indexOf(","));num2 = s.substring(s.indexOf(",")+1,s.indexOf(")"));n1 = Integer.parseInt(num);n2 = Integer.parseInt(num2);result = n1+n2;break;
					case "sub":num = s.substring(s.indexOf("(")+1,s.indexOf(","));num2 = s.substring(s.indexOf(",")+1,s.indexOf(")"));n1 = Integer.parseInt(num);n2 = Integer.parseInt(num2);result = n1+n2;break;
					case "min":num = s.substring(s.indexOf("(")+1,s.indexOf(","));num2 = s.substring(s.indexOf(",")+1,s.indexOf(")"));n1 = Integer.parseInt(num);n2 = Integer.parseInt(num2);result = n1<n2?n1:n2;break;
					case "double":num = s.substring(s.indexOf("(")+1,s.indexOf(")"));n1 = Integer.parseInt(num);result = n1*2;break;
					case "max":num = s.substring(s.indexOf("(")+1,s.indexOf(","));num2 = s.substring(s.indexOf(",")+1,s.indexOf(")"));n1 = Integer.parseInt(num);n2 = Integer.parseInt(num2);result = n1>n2?n1:n2;break;
					default:break;
			}
			
			
			return String.valueOf(result);
		}

	}


