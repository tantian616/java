package work6;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class one {
	
			public static void main(String[] args) {
			String FileName ="C:/Users/Administrator/Desktop/student .txt";
			try{
				File aFile = new File(FileName);
				FileReader fr = new FileReader(aFile);
				BufferedReader br = new BufferedReader(fr);
				String line= "";
				while((line=br.readLine())!=null){
					System.out.println(line);
				}
				br.close();
				fr.close();
				
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}

