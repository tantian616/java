package work5;

public class CourseResult {
	private String course;
	private double score;
	public CourseResult(String course,double score)
	{
		this.course=course;
		this.score=score;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	@Override
	public String toString() {
		return "CourseResult [course=" + course + ", score=" + score + "]";
	}
	

}
