package work5;

public class StudentScore {
	private String id;
	private String course;
	private double score;
	
	public StudentScore(String id,String course,double score)
	{
		this.id=id;
		this.course=course;
		this.score=score;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

	@Override
	public String toString() {
		return "StudentScore [id=" + id + ", course=" + course + ", score=" + score + "]";
	}
	

}
