package work5;

public class StudentResult {
	private String id;
	private String name;
	private String gender;
	private double average;
	public StudentResult(String id,String name,String gender,double average)
	{
		this.id=id;
		this.name=name;
		this.gender=gender;
		this.average=average;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public double getAverage() {
		return average;
	}
	public void setAverage(double average) {
		this.average = average;
	}
	@Override
	public String toString() {
		return "StudentResult [id=" + id + ", name=" + name + ", gender=" + gender + ", average=" + average + "]";
	}
	
	
}
