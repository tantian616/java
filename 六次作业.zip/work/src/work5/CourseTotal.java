package work5;

public class CourseTotal {
	private String course;
	private double total;
	private int num;

	public CourseTotal(String course, double total, int num) {
		
		this.course= course;
		this.total = total;
		this.num = num;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		course = course;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

}


