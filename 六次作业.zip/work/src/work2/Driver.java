package work2;

public class Driver {
	public static void main(String[] args)
	{
		Student a1=new Student("С��","15623232603","1904240414");
		Student a2=new Student("ͼͼ","17683858400","1904240416");
		System.out.println(a1.displayStudent());
		System.out.println(a2.displayStudent());
		
	}

}
