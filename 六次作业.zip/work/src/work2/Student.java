package work2;

public class Student {
	private String name;
	private String phoneNumber;
	private String studentNumber;
	public Student(String name, String phoneNumber, String studentNumber)
	{
		this.name=name;
		this.phoneNumber=phoneNumber;
		this.studentNumber=studentNumber;
	}
	//get and set
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getStudentNumber() {
		return studentNumber;
	}
	public void setStudentNumber(String studentNumber) {
		this.studentNumber = studentNumber;
	}
	public String displayStudent()
	{
		String msg;
		msg="name:"+this.name+"\n";
		msg+="phoneNumber:"+this.phoneNumber+"\n";
		msg+="studentNumber:"+this.studentNumber+"\n";
		
		return msg;
	}
	

}
